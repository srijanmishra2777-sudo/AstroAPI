from fastapi import FastAPI, HTTPException, Query
import swisseph as swe
from datetime import datetime
import pytz

app = FastAPI(title="Advanced Jyotish API with Outer Planets")

# --- Constants & Rules Configuration ---
SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", 
         "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]

# Exaltation (Uchcha) and Debilitation (Neecha) Deepest Points (Param Uchcha / Param Neecha)
# Format: {Planet_ID: (Exaltation_Sign_Index, Deepest_Degree)}
EXALTATION_DEBILITATION_RULES = {
    swe.SUN: {"exalt_sign": 0, "exalt_deg": 10, "debil_sign": 6, "debil_deg": 10},       # Sun: Exalted in Aries, Debilitated in Libra
    swe.MOON: {"exalt_sign": 1, "exalt_deg": 3, "debil_sign": 7, "debil_deg": 3},        # Moon: Taurus / Scorpio
    swe.MARS: {"exalt_sign": 9, "exalt_deg": 28, "debil_sign": 3, "debil_deg": 28},      # Mars: Capricorn / Cancer
    swe.MERCURY: {"exalt_sign": 5, "exalt_deg": 15, "debil_sign": 11, "debil_deg": 15},   # Mercury: Virgo / Pisces
    swe.JUPITER: {"exalt_sign": 3, "exalt_deg": 5, "debil_sign": 9, "debil_deg": 5},     # Jupiter: Cancer / Capricorn
    swe.VENUS: {"exalt_sign": 11, "exalt_deg": 27, "debil_sign": 5, "debil_deg": 27},    # Venus: Pisces / Virgo
    swe.SATURN: {"exalt_sign": 6, "exalt_deg": 20, "debil_sign": 0, "debil_deg": 20},     # Saturn: Libra / Aries
}

# Combustion (Astayana) Degrees from Sun (Traditional Vedic limits)
COMBUST_LIMITS = {
    swe.MOON: 12.0,
    swe.MARS: 17.0,
    swe.MERCURY: 14.0,  # 12 deg when retrograde
    swe.JUPITER: 11.0,
    swe.VENUS: 10.0,
    swe.SATURN: 15.0
}

def get_dignity(planet_id, sign_idx, deg_in_sign):
    """Calculate if a planet is Exalted, Debilitated, or Normal."""
    if planet_id not in EXALTATION_DEBILITATION_RULES:
        return "Normal"
    
    rules = EXALTATION_DEBILITATION_RULES[planet_id]
    
    # Simple check based on Sign boundaries
    if sign_idx == rules["exalt_sign"]:
        return "Exalted (Uchcha)"
    elif sign_idx == rules["debil_sign"]:
        return "Debilitated (Neecha)"
    
    return "Normal"

def get_house_number(planet_lon, ascendant_lon):
    """Calculate House number based on Whole Sign House System (Standard Vedic)."""
    asc_sign = int(ascendant_lon / 30)
    planet_sign = int(planet_lon / 30)
    
    house = (planet_sign - asc_sign) + 1
    if house <= 0:
        house += 12
    return house

@app.get("/api/v1/kundali")
def get_kundali(
    date: str = Query(..., description="Format: YYYY-MM-DD", example="1992-06-13"),
    time: str = Query(..., description="Format: HH:MM:SS (24hr Local Time)", example="19:43:00"),
    timezone: str = Query(..., description="IANA Timezone string", example="Asia/Kolkata"),
    latitude: float = Query(..., description="Latitude", example=26.8467),
    longitude: float = Query(..., description="Longitude", example=80.9462)
):
    try:
        # 1. Handling Time and Timezones (Converting local input to UTC)
        local_tz = pytz.timezone(timezone)
        local_dt_str = f"{date} {time}"
        local_dt = datetime.strptime(local_dt_str, "%Y-%m-%d %H:%M:%S")
        local_dt = local_tz.localize(local_dt)
        utc_dt = local_dt.astimezone(pytz.utc)

        # 2. Setup Swiss Ephemeris Settings
        swe.set_sid_mode(swe.SIDM_LAHIRI, 0, 0) # Using Lahiri Ayanamsa
        jd_ut = swe.julday(utc_dt.year, utc_dt.month, utc_dt.day, utc_dt.hour + utc_dt.minute/60.0 + utc_dt.second/3600.0)

        # 3. Calculate Ascendant (Lagna)
        # Using Whole Sign system ('W')
        houses, ascmc = swe.houses_ex(jd_ut, latitude, longitude, b'W', swe.FLG_SIDEREAL)
        ascendant_lon = ascmc[0]
        asc_sign_idx = int(ascendant_lon / 30)

        # 4. Define Planet Dictionary
        planets_to_calc = {
            "Sun": swe.SUN, "Moon": swe.MOON, "Mars": swe.MARS, 
            "Mercury": swe.MERCURY, "Jupiter": swe.JUPITER, "Venus": swe.VENUS, 
            "Saturn": swe.SATURN, "Rahu": swe.MEAN_NODE, "Uranus": swe.URANUS, 
            "Neptune": swe.NEPTUNE, "Pluto": swe.PLUTO
        }

        raw_positions = {}
        output_planets = {}

        # First pass: Calculate positions and retrograde status
        for name, body_id in planets_to_calc.items():
            res, ret = swe.calc_ut(jd_ut, body_id, swe.FLG_SIDEREAL | swe.FLG_SPEED)
            lon = res[0]
            speed = res[3] # Speed > 0 means Direct, Speed < 0 means Retrograde
            
            raw_positions[body_id] = lon
            sign_idx = int(lon / 30)

            output_planets[name] = {
                "longitude": round(lon, 4),
                "zodiac_sign": SIGNS[sign_idx],
                "degree_in_sign": round(lon % 30, 4),
                "house": get_house_number(lon, ascendant_lon),
                "is_retrograde": True if speed < 0 else False,
                "dignity": get_dignity(body_id, sign_idx, lon % 30),
                "is_combust": False # Default, will evaluate below
            }

        # Calculate Ketu (Exactly 180 degrees apart from Rahu)
        rahu_lon = raw_positions[swe.MEAN_NODE]
        ketu_lon = (rahu_lon + 180) % 360
        ketu_sign_idx = int(ketu_lon / 30)
        output_planets["Ketu"] = {
            "longitude": round(ketu_lon, 4),
            "zodiac_sign": SIGNS[ketu_sign_idx],
            "degree_in_sign": round(ketu_lon % 30, 4),
            "house": get_house_number(ketu_lon, ascendant_lon),
            "is_retrograde": output_planets["Rahu"]["is_retrograde"], # Follows Rahu
            "dignity": "Normal",
            "is_combust": False
        }

        # Second pass: Calculate Combustion (Astayana) against the Sun's position
        sun_lon = raw_positions[swe.SUN]
        for name, body_id in planets_to_calc.items():
            if body_id in COMBUST_LIMITS:
                p_lon = raw_positions[body_id]
                # Calculate angular distance handles 0/360 degree boundary wrap around
                diff = abs(p_lon - sun_lon)
                distance = min(diff, 360 - diff)
                
                # Check custom limit for Mercury if retrograde
                limit = COMBUST_LIMITS[body_id]
                if body_id == swe.MERCURY and output_planets["Mercury"]["is_retrograde"]:
                    limit = 12.0

                if distance <= limit:
                    output_planets[name]["is_combust"] = True

        # Combine Everything into Final Output
        response_data = {
            "meta": {
                "julian_day": jd_ut,
                "ayanamsa_degrees": round(swe.get_ayanamsa_ut(jd_ut), 4)
            },
            "ascendant": {
                "longitude": round(ascendant_lon, 4),
                "zodiac_sign": SIGNS[asc_sign_idx],
                "degree_in_sign": round(ascendant_lon % 30, 4)
            },
            "planets": output_planets
        }

        return response_data

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)